# ModaFacil PI Etapa 6

Projeto Java NetBeans refatorado para separar interface, regras de negocio e persistencia.

## Pacotes

- `model`: entidades Cliente e Produto.
- `view`: telas Swing.
- `service`: validacoes e regras de negocio.
- `repository`: contratos de persistencia e implementacoes em memoria.
- `dao`: acesso ao banco MySQL.
- `exception`: erros de validacao.
- `app`: testes executaveis pelo metodo `main()`.

## Executar os testes

Execute a classe `app.TesteRefatoracao`. Os testes usam repositorios em memoria e nao precisam de banco de dados.

## Configurar o MySQL

A tela de produtos usa `ProdutoDAO`. Antes de executar a interface, configure as variaveis de ambiente `DB_URL`, `DB_USER` e `DB_PASSWORD`. Se `DB_URL` nao for informada, o sistema usa o banco local `modafacil`.
