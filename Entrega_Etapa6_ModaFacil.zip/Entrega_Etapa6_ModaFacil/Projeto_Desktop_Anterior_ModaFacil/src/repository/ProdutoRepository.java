package repository;

import java.util.ArrayList;
import model.Produto;

public class ProdutoRepository {
    private ArrayList<Produto> lista = new ArrayList<>();

    public void adicionar(Produto p) {
        lista.add(p);
    }

    public ArrayList<Produto> listar() {
        return lista;
    }
}

