package repository;

import java.util.ArrayList;
import model.Cliente;

public class ClienteRepository {
    private ArrayList<Cliente> lista = new ArrayList<>();

    public void adicionar(Cliente c) {
        lista.add(c);
    }

    public ArrayList<Cliente> listar() {
        return lista;
    }
}

