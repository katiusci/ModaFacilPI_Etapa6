package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexao {

    private static final String URL =
"jdbc:mysql://localhost:3306/modafacil?useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true";



    public static Connection getConnection() throws SQLException {
        String usuario = System.getenv().getOrDefault("DB_USER", "root");
        String senha = System.getenv().getOrDefault("DB_PASSWORD", "");
        return DriverManager.getConnection(URL, usuario, senha);
    }
}

