package dao;

import model.Produto;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;


public class ProdutoDAO {

    public void inserir(Produto p) throws SQLException {
        String sql = "INSERT INTO Produto (nome, categoria, tamanho, preco, quantidadeEstoque) VALUES (?, ?, ?, ?, ?)";

        try (Connection con = Conexao.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, p.getNome());
            ps.setString(2, p.getCategoria());
            ps.setString(3, p.getTamanho());
            ps.setDouble(4, p.getPreco());
            ps.setInt(5, p.getQuantidadeEstoque());

            ps.executeUpdate();
        }
    }
    public List<Produto> listar() throws SQLException {
        String sql = "SELECT * FROM Produto ORDER BY nome";
        List<Produto> lista = new ArrayList<>();

        try (Connection con = Conexao.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Produto p = new Produto();
                p.setIdProduto(rs.getInt("idProduto"));
                p.setNome(rs.getString("nome"));
                p.setCategoria(rs.getString("categoria"));
                p.setTamanho(rs.getString("tamanho"));
                p.setPreco(rs.getDouble("preco"));
                p.setQuantidadeEstoque(rs.getInt("quantidadeEstoque"));

                lista.add(p);
            }
        }
        return lista;
    }
public void excluir(int id) throws Exception {

    String sql = "DELETE FROM produto WHERE idProduto = ?";

    Connection conn = Conexao.getConnection();
    PreparedStatement stmt = conn.prepareStatement(sql);

    stmt.setInt(1, id);
    stmt.execute();

    stmt.close();
    conn.close();
}

}
