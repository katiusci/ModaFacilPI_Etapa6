import dao.ProdutoDAO;
import model.Produto;

public class TesteProdutoInsert {
    public static void main(String[] args) {
        try {
            Produto p = new Produto();
            p.setNome("Camiseta Teste");
            p.setCategoria("Camisetas");
            p.setTamanho("M");
            p.setPreco(12.90);
            p.setQuantidadeEstoque(20);

            new ProdutoDAO().inserir(p);

            System.out.println("✅ Produto inserido no banco com sucesso!");
        } catch (Exception e) {
            System.out.println("❌ Erro ao inserir:");
            e.printStackTrace();
        }
    }
}

