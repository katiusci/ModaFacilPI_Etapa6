CREATE DATABASE IF NOT EXISTS modafacil;
USE modafacil;

CREATE TABLE IF NOT EXISTS Produto (
    idProduto INT NOT NULL AUTO_INCREMENT,
    nome VARCHAR(120) NOT NULL,
    categoria VARCHAR(80) NOT NULL,
    tamanho VARCHAR(20) NOT NULL,
    preco DECIMAL(10, 2) NOT NULL,
    quantidadeEstoque INT NOT NULL,
    PRIMARY KEY (idProduto)
);
