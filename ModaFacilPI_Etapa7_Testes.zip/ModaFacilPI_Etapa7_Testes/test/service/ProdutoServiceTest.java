package service;

import exception.ValidacaoException;
import model.Produto;
import org.junit.Before;
import org.junit.Test;
import repository.ProdutoRepositoryMemoria;

import static org.junit.Assert.assertEquals;

public class ProdutoServiceTest {

    private ProdutoService service;

    @Before
    public void prepararTeste() {
        service = new ProdutoService(new ProdutoRepositoryMemoria());
    }

    @Test
    public void deveCalcularValorTotalDoEstoque() throws Exception {
        Produto produto = criarProduto(49.90, 6);

        double resultado = service.calcularValorEstoque(produto);

        assertEquals(299.40, resultado, 0.001);
    }

    @Test
    public void deveCadastrarProdutoValido() throws Exception {
        Produto produto = criarProduto(79.90, 3);

        service.cadastrar(produto);

        assertEquals(1, service.listar().size());
        assertEquals("Vestido", service.listar().get(0).getNome());
    }

    @Test(expected = ValidacaoException.class)
    public void deveRejeitarProdutoComPrecoNegativo() throws Exception {
        Produto produto = criarProduto(-10.00, 2);

        service.cadastrar(produto);
    }

    private Produto criarProduto(double preco, int quantidade) {
        Produto produto = new Produto();
        produto.setNome("Vestido");
        produto.setCategoria("Feminino");
        produto.setTamanho("M");
        produto.setPreco(preco);
        produto.setQuantidadeEstoque(quantidade);
        return produto;
    }
}
