package repository;

import java.util.List;
import model.Produto;

/** Contrato de persistencia de produtos. */
public interface ProdutoRepository {
    void adicionar(Produto produto) throws Exception;
    void atualizar(Produto produto) throws Exception;
    void excluir(int id) throws Exception;
    List<Produto> listar() throws Exception;
}
