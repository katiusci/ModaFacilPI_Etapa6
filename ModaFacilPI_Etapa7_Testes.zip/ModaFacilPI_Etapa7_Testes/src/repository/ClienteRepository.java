package repository;

import java.util.List;
import model.Cliente;

/** Contrato de persistencia de clientes. */
public interface ClienteRepository {
    void adicionar(Cliente cliente);
    void atualizar(Cliente cliente);
    void excluir(int id);
    List<Cliente> listar();
}
