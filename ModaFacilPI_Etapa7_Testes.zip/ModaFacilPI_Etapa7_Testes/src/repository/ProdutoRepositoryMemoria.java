package repository;

import java.util.ArrayList;
import java.util.List;
import model.Produto;

/** Implementacao em memoria usada pelos testes do metodo main. */
public class ProdutoRepositoryMemoria implements ProdutoRepository {
    private final List<Produto> produtos = new ArrayList<>();
    private int proximoId = 1;

    @Override
    public void adicionar(Produto produto) {
        if (produto.getIdProduto() <= 0) produto.setIdProduto(proximoId++);
        produtos.add(produto);
    }

    @Override
    public void atualizar(Produto produto) {
        for (int i = 0; i < produtos.size(); i++) {
            if (produtos.get(i).getIdProduto() == produto.getIdProduto()) {
                produtos.set(i, produto);
                return;
            }
        }
        throw new IllegalArgumentException("Produto nao encontrado.");
    }

    @Override
    public void excluir(int id) {
        produtos.removeIf(produto -> produto.getIdProduto() == id);
    }

    @Override
    public List<Produto> listar() {
        return new ArrayList<>(produtos);
    }
}
