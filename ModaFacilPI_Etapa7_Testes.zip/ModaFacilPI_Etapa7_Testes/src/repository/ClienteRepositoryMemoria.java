package repository;

import java.util.ArrayList;
import java.util.List;
import model.Cliente;

/** Implementacao em memoria utilizada pela interface de clientes. */
public class ClienteRepositoryMemoria implements ClienteRepository {
    private final List<Cliente> clientes = new ArrayList<>();

    @Override
    public void adicionar(Cliente cliente) {
        clientes.add(cliente);
    }

    @Override
    public void atualizar(Cliente cliente) {
        for (int i = 0; i < clientes.size(); i++) {
            if (clientes.get(i).getId() == cliente.getId()) {
                clientes.set(i, cliente);
                return;
            }
        }
        throw new IllegalArgumentException("Cliente nao encontrado.");
    }

    @Override
    public void excluir(int id) {
        clientes.removeIf(cliente -> cliente.getId() == id);
    }

    @Override
    public List<Cliente> listar() {
        return new ArrayList<>(clientes);
    }
}
