package app;

import exception.ValidacaoException;
import model.Cliente;
import model.Produto;
import repository.ClienteRepositoryMemoria;
import repository.ProdutoRepositoryMemoria;
import service.ClienteService;
import service.ProdutoService;

/** Testes simples solicitados na atividade, executados pelo metodo main. */
public class TesteRefatoracao {

    public static void main(String[] args) throws Exception {
        testarProduto();
        testarCliente();
        System.out.println("Todos os testes da refatoracao foram concluidos.");
    }

    private static void testarProduto() throws Exception {
        ProdutoService service = new ProdutoService(new ProdutoRepositoryMemoria());

        Produto produto = new Produto();
        produto.setNome("Camiseta basica");
        produto.setCategoria("Camisetas");
        produto.setTamanho("M");
        produto.setPreco(29.90);
        produto.setQuantidadeEstoque(10);
        service.cadastrar(produto);

        verificar(service.listar().size() == 1, "Cadastro de produto");

        produto.setPreco(34.90);
        service.atualizar(produto);
        verificar(service.listar().get(0).getPreco() == 34.90, "Atualizacao de produto");

        try {
            Produto invalido = new Produto();
            invalido.setPreco(-1);
            service.cadastrar(invalido);
            throw new IllegalStateException("A validacao deveria impedir o cadastro.");
        } catch (ValidacaoException esperado) {
            System.out.println("[OK] Validacao de produto invalido");
        }

        service.excluir(produto.getIdProduto());
        verificar(service.listar().isEmpty(), "Exclusao de produto");
    }

    private static void testarCliente() throws Exception {
        ClienteService service = new ClienteService(new ClienteRepositoryMemoria());
        Cliente cliente = new Cliente(1, "Maria Souza", "912345678");
        service.cadastrar(cliente);
        verificar(service.listar().size() == 1, "Cadastro de cliente");

        cliente.setTelefone("913456789");
        service.atualizar(cliente);
        verificar("913456789".equals(service.listar().get(0).getTelefone()), "Atualizacao de cliente");

        service.excluir(cliente.getId());
        verificar(service.listar().isEmpty(), "Exclusao de cliente");
    }

    private static void verificar(boolean condicao, String descricao) {
        if (!condicao) throw new IllegalStateException("Falha: " + descricao);
        System.out.println("[OK] " + descricao);
    }
}
