package service;

import exception.ValidacaoException;
import java.util.List;
import model.Produto;
import repository.ProdutoRepository;

/** Reune exclusivamente as regras de negocio de produtos. */
public class ProdutoService {
    private final ProdutoRepository repository;

    public ProdutoService(ProdutoRepository repository) {
        this.repository = repository;
    }

    public void cadastrar(Produto produto) throws Exception {
        validar(produto, false);
        repository.adicionar(produto);
    }

    public void atualizar(Produto produto) throws Exception {
        validar(produto, true);
        repository.atualizar(produto);
    }

    public void excluir(int id) throws Exception {
        if (id <= 0) throw new ValidacaoException("O ID do produto deve ser maior que zero.");
        repository.excluir(id);
    }

    public List<Produto> listar() throws Exception {
        return repository.listar();
    }

    /** Calcula o valor financeiro dos itens disponíveis no estoque. */
    public double calcularValorEstoque(Produto produto) throws ValidacaoException {
        validar(produto, false);
        return produto.getPreco() * produto.getQuantidadeEstoque();
    }

    private void validar(Produto produto, boolean exigirId) throws ValidacaoException {
        if (produto == null) throw new ValidacaoException("Informe os dados do produto.");
        if (exigirId && produto.getIdProduto() <= 0) throw new ValidacaoException("O ID do produto deve ser maior que zero.");
        if (vazio(produto.getNome())) throw new ValidacaoException("Informe o nome do produto.");
        if (vazio(produto.getCategoria())) throw new ValidacaoException("Informe a categoria do produto.");
        if (vazio(produto.getTamanho())) throw new ValidacaoException("Informe o tamanho do produto.");
        if (produto.getPreco() <= 0) throw new ValidacaoException("O preco deve ser maior que zero.");
        if (produto.getQuantidadeEstoque() < 0) throw new ValidacaoException("O estoque nao pode ser negativo.");
    }

    private boolean vazio(String valor) {
        return valor == null || valor.trim().isEmpty();
    }
}
