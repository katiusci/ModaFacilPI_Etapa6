package service;

import exception.ValidacaoException;
import java.util.List;
import model.Cliente;
import repository.ClienteRepository;

/** Reune exclusivamente as regras de negocio de clientes. */
public class ClienteService {
    private final ClienteRepository repository;

    public ClienteService(ClienteRepository repository) {
        this.repository = repository;
    }

    public void cadastrar(Cliente cliente) throws ValidacaoException {
        validar(cliente);
        repository.adicionar(cliente);
    }

    public void atualizar(Cliente cliente) throws ValidacaoException {
        validar(cliente);
        repository.atualizar(cliente);
    }

    public void excluir(int id) throws ValidacaoException {
        if (id <= 0) throw new ValidacaoException("O ID do cliente deve ser maior que zero.");
        repository.excluir(id);
    }

    public List<Cliente> listar() {
        return repository.listar();
    }

    private void validar(Cliente cliente) throws ValidacaoException {
        if (cliente == null) throw new ValidacaoException("Informe os dados do cliente.");
        if (cliente.getId() <= 0) throw new ValidacaoException("O ID do cliente deve ser maior que zero.");
        if (vazio(cliente.getNome())) throw new ValidacaoException("Informe o nome do cliente.");
        if (vazio(cliente.getTelefone())) throw new ValidacaoException("Informe o telefone do cliente.");
    }

    private boolean vazio(String valor) {
        return valor == null || valor.trim().isEmpty();
    }
}
