package dao;

import model.Produto;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import repository.ProdutoRepository;


public class ProdutoDAO implements ProdutoRepository {

    @Override
    public void adicionar(Produto p) throws SQLException {
        String sql = "INSERT INTO Produto (nome, categoria, tamanho, preco, quantidadeEstoque) VALUES (?, ?, ?, ?, ?)";

        try (Connection con = Conexao.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, p.getNome());
            ps.setString(2, p.getCategoria());
            ps.setString(3, p.getTamanho());
            ps.setDouble(4, p.getPreco());
            ps.setInt(5, p.getQuantidadeEstoque());

            ps.executeUpdate();
        }
    }
    @Override
    public List<Produto> listar() throws SQLException {
        String sql = "SELECT * FROM Produto ORDER BY nome";
        List<Produto> lista = new ArrayList<>();

        try (Connection con = Conexao.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Produto p = new Produto();
                p.setIdProduto(rs.getInt("idProduto"));
                p.setNome(rs.getString("nome"));
                p.setCategoria(rs.getString("categoria"));
                p.setTamanho(rs.getString("tamanho"));
                p.setPreco(rs.getDouble("preco"));
                p.setQuantidadeEstoque(rs.getInt("quantidadeEstoque"));

                lista.add(p);
            }
        }
        return lista;
    }

    @Override
    public void atualizar(Produto p) throws SQLException {
        String sql = "UPDATE Produto SET nome=?, categoria=?, tamanho=?, preco=?, quantidadeEstoque=? WHERE idProduto=?";
        try (Connection con = Conexao.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, p.getNome());
            ps.setString(2, p.getCategoria());
            ps.setString(3, p.getTamanho());
            ps.setDouble(4, p.getPreco());
            ps.setInt(5, p.getQuantidadeEstoque());
            ps.setInt(6, p.getIdProduto());
            ps.executeUpdate();
        }
    }

    @Override
    public void excluir(int id) throws SQLException {
        String sql = "DELETE FROM Produto WHERE idProduto = ?";
        try (Connection con = Conexao.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }

}
