package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexao {

    private static final String URL_PADRAO =
            "jdbc:mysql://localhost:3306/modafacil?useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true";

    public static Connection getConnection() throws SQLException {
        String url = obterConfiguracao("DB_URL", URL_PADRAO);
        String usuario = obterConfiguracao("DB_USER", "root");
        String senha = obterConfiguracao("DB_PASSWORD", "");
        return DriverManager.getConnection(url, usuario, senha);
    }

    private static String obterConfiguracao(String nome, String valorPadrao) {
        String valor = System.getenv(nome);
        return valor == null || valor.isBlank() ? valorPadrao : valor;
    }
}

