package exception;

/** Erro de regra de negocio que pode ser apresentado ao usuario. */
public class ValidacaoException extends Exception {
    public ValidacaoException(String mensagem) {
        super(mensagem);
    }
}
