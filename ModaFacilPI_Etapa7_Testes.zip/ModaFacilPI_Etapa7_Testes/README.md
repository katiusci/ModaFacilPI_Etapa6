# ModaFacil PI Etapa 7 Testes

Projeto Java NetBeans com testes unitarios JUnit 4, desenvolvido a partir do sistema refatorado na Etapa 6.

## Funcionalidade testada

A classe `ProdutoService` possui o metodo `calcularValorEstoque`, que calcula o preco do produto multiplicado pela quantidade em estoque. Os testes tambem verificam o cadastro de um produto valido e a rejeicao de preco negativo.

## Executar no NetBeans

1. Abra a pasta do projeto no NetBeans.
2. Clique com o botao direito no projeto.
3. Selecione `Test` ou `Testar`.

Os testes estao em `test/service/ProdutoServiceTest.java` e utilizam um repositorio em memoria. Nao e necessario conectar ao MySQL.
